# Informations pour la soumission

- **Nom** : Ariel Assayag
- **Adresse e-mail** : an.assayag@gmail.com
- **Lien vers le dépôt GitHub** : [https://github.com/Al-Sayagh/examen_dvc](https://github.com/Al-Sayagh/examen_dvc)
- **Lien vers le dépôt DagsHub** : [https://dagshub.com/Al-Sayagh/examen_dvc](https://dagshub.com/Al-Sayagh/examen_dvc)
